在5个代码中，client.py为客户端代码，server.py为服务器代码，backup_server.py为备份服务器代码，acceptor1.py、acceptor2.py均为接受者服务器。
在运行前，需要先给5份代码均分配一个文件根目录。
在运行时，需要先运行backup_server.py以及acceptor1.py和acceptor2.py，而后再运行server.py，最后运行client.py
client.py运行后需要先注册并登陆才能使用正常的功能，每次操作都需要选定一个文件夹进行操作，只需按照终端的提示按步骤操作即可。