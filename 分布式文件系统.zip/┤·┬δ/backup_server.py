from xmlrpc.server import SimpleXMLRPCServer
from xmlrpc.server import SimpleXMLRPCRequestHandler
import os
import shutil

# Restrict to a particular path.
class RequestHandler(SimpleXMLRPCRequestHandler):
    rpc_paths = ('/RPC_backup',)

# Backup Server
class BackupServer:
    def __init__(self, root_dir):
        self.root_dir = root_dir
        if not os.path.exists(self.root_dir):
            os.makedirs(self.root_dir)

    def list_files(self, file_path):
        dir = self.root_dir + file_path
        return os.listdir(dir)

    def read_file(self, filename):
        file_path = os.path.join(self.root_dir, filename)
        Recycle_file_path = os.path.join(self.root_dir,"Recycle", filename)
        print("Backup server tries to restore files")
        if os.path.exists(file_path):
            with open(file_path, 'rb') as file:
                return file.read()
        elif os.path.exists(Recycle_file_path):
            
            with open(Recycle_file_path, 'rb') as file:
                temp=file.read()
            with open(file_path, 'wb') as file:
                file.write(temp)
            return temp
        else:
            return -1

    def write_file(self, filename, content):
        file_path = os.path.join(self.root_dir, filename)
        with open(file_path, 'wb') as file:
            file.write(content.data)
        print(f"Back up:write {content.data.decode()}")
        return True


    def delete_file(self, filename):
        file_path = os.path.join(self.root_dir, filename)
        if os.path.exists(file_path):
            if os.path.isdir(file_path):
                try:
                    destination_folder = os.path.join(self.root_dir, 'Recycle', os.path.basename(file_path))
                    print(destination_folder)
                    shutil.copytree(file_path, destination_folder)
                except Exception as e:
                    print(f"Error copying folder: {e}")
                
                shutil.rmtree(file_path)
            else:
                shutil.copy(file_path, os.path.join(self.root_dir, 'Recycle'))
                print(f"{os.path.basename(file_path)} has been deleted and moved into Recycle")
                os.remove(file_path)
            return True
        else:
            return False

    def create_dir(self, dir_path, dir_name):
        new_dir_path = os.path.join(self.root_dir, dir_path, dir_name)
        if not os.path.exists(new_dir_path):
            os.makedirs(new_dir_path)
            return True
        else:
            return False

# Create server
backup_server = SimpleXMLRPCServer(('localhost', 8001), requestHandler=RequestHandler)
backup_server.register_introspection_functions()

# Register Backup server functions
backup_server_instance = BackupServer("D:\\原E盘\\中山大学学习工作资料\\大三\\大三上\\分布式系统\\大作业\\data_store\\to\\backup_root")
backup_server.register_instance(backup_server_instance, allow_dotted_names=True)

# Run the server's main loop
backup_server.serve_forever()
