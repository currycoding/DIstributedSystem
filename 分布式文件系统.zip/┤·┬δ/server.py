from xmlrpc.server import SimpleXMLRPCServer, SimpleXMLRPCRequestHandler
from xmlrpc.client import ServerProxy
import os
import shutil
import time
from collections import defaultdict
import threading

# Restrict to a particular path.
class RequestHandler(SimpleXMLRPCRequestHandler):
    rpc_paths = ('/RPC2',)

# NFS Server
backup_url = 'http://localhost:8001/RPC_backup'

class NFSServer:
    def __init__(self, root_dir, backup_url, node_id, acceptors):
        self.root_dir = root_dir
        self.node_id = node_id
        self.proposal_number = 0
        self.proposal_value = "None"
        self.lock = defaultdict(lambda: "unlock")
        self.autor = defaultdict(lambda: [-1, 0, 0, 0, 0, 0])
        self.cal = 0
        self.autor['00001'] = ["1234", 1, 1, 1, 1, 1]
        self.acceptors = acceptors
        self.proposor = None
        self.backup_server = ServerProxy(backup_url)
        if not os.path.exists(self.root_dir):
            os.makedirs(self.root_dir)

    def Paxos_pro(self, content):
        self.proposal_number += 1
        self.proposal_value = content
        self.cal = 0
        for acceptor in self.acceptors:
            accept = acceptor.receive_prepare(self.proposal_number)
            accnum = accept[0]
            temp = accnum
            accval = accept[1]
            if accnum != -1:
                self.cal += 1
                if accnum >= temp and accnum != 0:
                    temp = accnum
                    self.proposal_value = accval
        if self.cal >= len(self.acceptors) / 2:
            for acceptor in self.acceptors:
                return_pro_num = acceptor.receive_accept(
                    self.proposal_number, self.proposal_value
                )
                if return_pro_num > self.proposal_number:
                    print("unsuccessful")
                    return -1

            return self.proposal_value
        else:
            return -1

    def register(self, uid, password):
        self.autor[uid] = [password, 0, 0, 0, 0, 0]
        print(f"User {uid} register successfully, password={password}")
        return True

    def log_in(self, uid, password):
        if self.autor[uid][0] == password and password != -1:
            self.autor[uid] = [password, 1, 1, 0, 0, 0]
            print(f"User {uid} logged in.")
            return True
        else:
            return False

    def upgrade_user(self, uid):
        print(self.autor[uid])
        self.autor[uid] = [self.autor[uid][0], 1, 1, 1, 1, 1]
        print(
            f"User {uid} has upgraded. Now he is a super user who can write modify the file on the server."
        )
        return True

    def list_files(self, file_path, uid):
        if self.autor[uid][1] == 1:
            if self.lock[file_path] != "X":
                lock_state = self.lock[file_path]
                self.lock[file_path] = "S"
                dir = os.path.join(self.root_dir, file_path)
                self.lock[file_path] = lock_state
                return os.listdir(dir)
            else:
                return -3
        else:
            return -2

    def read_file(self, filename, uid):
        if self.autor[uid][2] == 1:
            if self.lock[filename] != "X":
                print(f"{filename}:{self.lock[filename]}")
                lock_state = self.lock[filename]
                self.lock[filename] = "S"
                time.sleep(20)
                print(f"User {uid} accessed {os.path.basename(filename)}")
                file_path = os.path.join(self.root_dir, filename)
                if os.path.exists(file_path):
                    with open(file_path, "rb") as file:
                        self.lock[filename] = lock_state
                        return file.read()
                else:
                    loss_data = self.backup_server.read_file(filename)
                    if loss_data != -1:
                        self.write_file(filename, loss_data)
                    self.lock[filename] = lock_state
                    return loss_data
            else:
                return -3
        else:
            return -2

    def write_file(self, filename, content, uid):
        if self.autor[uid][3] == 1:
            file_path = os.path.join(self.root_dir, filename)
            if os.path.exists(file_path):
                if self.lock[filename] == "unlock":
                    print(f"{filename}:{self.lock[filename]}")
                    self.lock[filename] = "X"
                    content = self.Paxos_pro(content)
                    if content != -1:
                        self.backup_server.write_file(filename, content)
                        with open(file_path, "wb") as file:
                            file.write(content.data)

                        for acceptor in self.acceptors:
                            acceptor.refresh()
                        print(f"User {uid} modified {filename}")
                        self.lock[filename] = "unlock"
                        return True
                    self.lock[filename] = "unlock"
                    return False
                else:
                    return -3
            else:
                dir, base = os.path.split(filename)
                if self.lock[dir] == "unlock":
                    self.lock[dir] = "X"
                    content = self.Paxos_pro(content)
                    if content != -1:
                        self.backup_server.write_file(filename, content)
                        with open(file_path, "wb") as file:
                            file.write(content.data)

                        for acceptor in self.acceptors:
                            acceptor.refresh()
                        print(f"User {uid} modified {filename}")
                        self.lock[dir] = "unlock"
                        return True
                    self.lock[filename] = "unlock"
                    return False
                else:
                    return -3
        else:
            return -2

    def delete_file(self, filename, uid):
        if self.autor[uid][4] == 1:
            if self.lock[filename] == "unlock":
                self.lock[filename] = "X"
                file_path = os.path.join(self.root_dir, filename)
                self.backup_server.delete_file(filename)
                if os.path.exists(file_path):
                    if os.path.isdir(file_path):
                        shutil.rmtree(file_path)
                    else:
                        os.remove(file_path)
                    print(f"User {uid} deleted {filename}")
                    del self.lock[filename]
                    return True
                else:
                    return False
            else:
                return -3
        else:
            return -2

    def create_dir(self, dir_path, dir_name, uid):
        if self.autor[uid][5] == 1:
            if self.lock[dir_path] == "unlock":
                self.lock[dir_path] = "X"
                new_dir_path = os.path.join(self.root_dir, dir_path, dir_name)
                self.backup_server.create_dir(dir_path, dir_name)
                if not os.path.exists(new_dir_path):
                    os.makedirs(new_dir_path)
                    print(f"Directory {dir_name} is created by User {uid}")
                    self.lock[dir_path] = "unlock"
                    return True
                else:
                    self.lock[dir_path] = "unlock"
                    return False
        else:
            return -2

# 多线程 XML-RPC 服务器
from xmlrpc.server import SimpleXMLRPCServer, SimpleXMLRPCRequestHandler
from xmlrpc.client import ServerProxy
import os
import shutil
import time
from collections import defaultdict
from socketserver import ThreadingMixIn
import threading

# Restrict to a particular path.
class RequestHandler(SimpleXMLRPCRequestHandler):
    rpc_paths = ('/RPC2',)

# NFS Server
backup_url = 'http://localhost:8001/RPC_backup'

class NFSServer:
    def __init__(self, root_dir, backup_url, node_id, acceptors):
        self.root_dir = root_dir
        self.node_id = node_id
        self.proposal_number = 0
        self.proposal_value = "None"
        self.lock = defaultdict(lambda: "unlock")
        self.autor = defaultdict(lambda: [-1, 0, 0, 0, 0, 0])
        self.cal = 0
        # self.autor['00001'] = ["1234", 1, 1, 1, 1, 1]
        self.acceptors = acceptors
        self.proposor = None
        self.backup_server = ServerProxy(backup_url)
        if not os.path.exists(self.root_dir):
            os.makedirs(self.root_dir)

    def Paxos_pro(self, content):
        self.proposal_number += 1
        self.proposal_value = content
        self.cal = 0
        for acceptor in self.acceptors:
            accept = acceptor.receive_prepare(self.proposal_number)
            accnum = accept[0]
            temp = accnum
            accval = accept[1]
            if accnum != -1:
                self.cal += 1
                if accnum >= temp and accnum != 0:
                    temp = accnum
                    self.proposal_value = accval
        if self.cal >= len(self.acceptors) / 2:
            for acceptor in self.acceptors:
                return_pro_num = acceptor.receive_accept(
                    self.proposal_number, self.proposal_value
                )
                if return_pro_num > self.proposal_number:
                    print("unsuccessful")
                    return -1

            return self.proposal_value
        else:
            return -1

    def register(self, uid, password):
        self.autor[uid] = [password, 0, 0, 0, 0, 0]
        print(f"User {uid} register successfully, password={password}")
        return True

    def log_in(self, uid, password):
        if self.autor[uid][0] == password and password != -1:
            self.autor[uid] = [password, 1, 1, 0, 0, 0]
            print(f"User {uid} logged in.")
            return True
        else:
            return False

    def upgrade_user(self, uid):
        print(self.autor[uid])
        self.autor[uid] = [self.autor[uid][0], 1, 1, 1, 1, 1]
        print(
            f"User {uid} has upgraded. Now he is a super user who can write modify the file on the server."
        )
        return True

    def list_files(self, file_path, uid):
        if self.autor[uid][1] == 1:
            if self.lock[file_path] != "X":
                lock_state = self.lock[file_path]
                self.lock[file_path] = "S"
                dir = os.path.join(self.root_dir, file_path)
                self.lock[file_path] = lock_state
                return os.listdir(dir)
            else:
                return -3
        else:
            return -2

    def read_file(self, filename, uid):
        if self.autor[uid][2] == 1:
            if self.lock[filename] != "X":
                #print(f"{filename}:{self.lock[filename]}")
                lock_state = self.lock[filename]
                self.lock[filename] = "S"
                time.sleep(20)
                print(f"User {uid} accessed {os.path.basename(filename)}")
                file_path = os.path.join(self.root_dir, filename)
                if os.path.exists(file_path):
                    with open(file_path, "rb") as file:
                        self.lock[filename] = lock_state
                        return file.read()
                else:
                    loss_data = self.backup_server.read_file(filename)
                    if loss_data != -1:
                        self.write_file(filename, loss_data,uid)
                    self.lock[filename] = lock_state
                    print("File restored from backup server")
                    return loss_data
            else:
                return -3
        else:
            return -2

    def write_file(self, filename, content, uid):
        if self.autor[uid][3] == 1:
            file_path = os.path.join(self.root_dir, filename)
            if os.path.exists(file_path):
                if self.lock[filename] == "unlock":
                    print(f"{filename}:{self.lock[filename]}")
                    self.lock[filename] = "X"
                    content = self.Paxos_pro(content)
                    print(f"Accepted value: {content}")
                    if content != -1:
                        self.backup_server.write_file(filename, content)
                        with open(file_path, "wb") as file:
                            file.write(content.data)

                        for acceptor in self.acceptors:
                            acceptor.refresh()
                        print(f"User {uid} modified {filename}")
                        self.lock[filename] = "unlock"
                        return True
                    self.lock[filename] = "unlock"
                    return False
                else:
                    return -3
            else:
                dir, base = os.path.split(filename)
                if self.lock[dir] == "unlock":
                    self.lock[dir] = "X"
                    content = self.Paxos_pro(content)
                    if content != -1:
                        self.backup_server.write_file(filename, content)
                        with open(file_path, "wb") as file:
                            file.write(content.data)

                        for acceptor in self.acceptors:
                            acceptor.refresh()
                        print(f"User {uid} modified {filename}")
                        self.lock[dir] = "unlock"
                        return True
                    self.lock[filename] = "unlock"
                    return False
                else:
                    return -3
        else:
            return -2

    def delete_file(self, filename, uid):
        if self.autor[uid][4] == 1:
            if self.lock[filename] == "unlock":
                self.lock[filename] = "X"
                file_path = os.path.join(self.root_dir, filename)
                self.backup_server.delete_file(filename)
                if os.path.exists(file_path):
                    if os.path.isdir(file_path):
                        shutil.rmtree(file_path)
                    else:
                        os.remove(file_path)
                    print(f"User {uid} deleted {filename}")
                    del self.lock[filename]
                    return True
                else:
                    return False
            else:
                return -3
        else:
            return -2

    def create_dir(self, dir_path, dir_name, uid):
        if self.autor[uid][5] == 1:
            if self.lock[dir_path] == "unlock":
                self.lock[dir_path] = "X"
                new_dir_path = os.path.join(self.root_dir, dir_path, dir_name)
                self.backup_server.create_dir(dir_path, dir_name)
                if not os.path.exists(new_dir_path):
                    os.makedirs(new_dir_path)
                    print(f"Directory {dir_name} is created by User {uid}")
                    self.lock[dir_path] = "unlock"
                    return True
                else:
                    self.lock[dir_path] = "unlock"
                    return False
            else:
                return -3
        else:
            return -2

# 多线程 XML-RPC 服务器
class ThreadedXMLRPCServer(ThreadingMixIn, SimpleXMLRPCServer):
    pass

if __name__ == "__main__":
    server = ThreadedXMLRPCServer(("localhost", 8000), RequestHandler)
    server.register_introspection_functions()
    acc = [
        ServerProxy("http://localhost:60000/RPC_receptor1"),
        ServerProxy("http://localhost:60001/RPC_receptor2"),
    ]
    nfs_server = NFSServer(
        "D:\\原E盘\\中山大学学习工作资料\\大三\\大三上\\分布式系统\\大作业\\data_store\\to\\nfs_root",
        backup_url,
        1,
        acc,
    )
    server.register_instance(nfs_server)

    # Start the server in a separate thread
    server_thread = threading.Thread(target=server.serve_forever)
    server_thread.daemon = True
    server_thread.start()

    print("Server started on port 8000.")

    try:
        server_thread.join()
    except KeyboardInterrupt:
        print("Server stopped.")