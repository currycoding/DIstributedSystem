from xmlrpc.client import ServerProxy
from xmlrpc.client import Binary
import base64
import os
from PIL import Image
from io import BytesIO
import tkinter as tk
from tkinter import scrolledtext
from collections import defaultdict
import time

# NFS Client
class NFSClient:
    def __init__(self, server_url,max_cache_size):
        self.server = ServerProxy(server_url)
        self.version_list=defaultdict(int)
        self.version_read=defaultdict(int)
        self.uid="00001"
        
        self.cache = {}
        
        self.cache_size=max_cache_size
    def register(self,password):
        self.server.register(self.uid,password)
    def log_in(self,password):
        return self.server.log_in(self.uid,password)
    def upgrade(self):
        return self.server.upgrade_user(self.uid)
    def cache_update(self):
        print("#####LRU PROCESS BEGIN")
        print("-------Current cache-------")
        for key, value in self.cache.items():
            print(f"{key}: {value}")
        print("----------------")
        cache_prio=sorted(self.cache, key=lambda x: self.cache[x][2])
        print(f"Least Recently Used:{self.cache[cache_prio[0]]}")
        print("#####LRU PROCESS END:")
        del self.cache[cache_prio[0]]
        
        
    def list_files(self,file_path):
        if file_path in self.cache and self.cache[file_path][1]==self.version_list[file_path]:
            self.cache[file_path][2]=time.time()
            print("**list from main memmory**")
            print("-------Current cache-------")
            for key, value in self.cache.items():
                print(f"{key}: {value}")
            print("----------------")
            return self.cache[file_path][0]
        if(len(self.cache)==self.cache_size):
            self.cache_update()
        self.cache[file_path] = [self.server.list_files(file_path,self.uid),self.version_list[file_path],time.time()]
        return self.cache[file_path][0]

    def read_file(self, filename):        
        name, file_extension = os.path.splitext(filename)
        if not bool(file_extension):
            if filename in self.cache and self.cache[filename][1]==self.version_list[filename]:
                self.cache[filename][2]=time.time()
                print("**list from main memmory**")
                print("-------Current cache-------")
                for key, value in self.cache.items():
                    print(f"{key}: {value}")
                return self.cache[filename][0]
            if(len(self.cache)==self.cache_size):
                self.cache_update()
            self.cache[filename] = [self.server.list_files(filename,self.uid),self.version_list[filename],time.time()]
            return self.cache[filename][0]
        else:
            if filename in self.cache and self.cache[filename][1]==self.version_read[filename]:
                self.cache[filename][2]=time.time()
                print("**read from main memmory**")
                return self.cache[filename][0]
            res=self.server.read_file(filename,self.uid)
            if res == -1:
                return res
            if(len(self.cache)==self.cache_size):
                self.cache_update()
            self.cache[filename] = [res,self.version_read[filename],time.time()]
            return self.cache[filename][0]
    
    def create_dir(self, path,filename):
        self.version_list[os.path.dirname(filename)]+=1
        return self.server.create_dir(path,filename,self.uid)

    def write_file(self, filename, content):
        self.version_read[filename]+=1
        return self.server.write_file(filename,content,self.uid)

    def delete_file(self, filename):
        self.version_list[os.path.dirname(filename)]+=1
        return self.server.delete_file(filename,self.uid)

# Example Usage
client = NFSClient('http://localhost:8000/RPC2',3)
client_root="D:\\原E盘\\中山大学学习工作资料\\大三\\大三上\\分布式系统\\大作业\\client_data"
valid_commands = ['create_dir', 'upload', 'write', 'read', 'download', 'delete']
# List files
#
#
# Write a file
log_in=0
while(True):
    print("Please enter a command:")
    command=input()
    if command=='register':
        print("Please enter your password to register:")
        password=input()
        client.register(password)
    elif command=='log_in':
        print("Please enter your password to log in:")
        password=input()
        if client.log_in(password):
            log_in=1
            print("Log in successful!")
        else:
            print("Password error")
    elif not log_in:
        print("Please log in first")
    elif command=='upgrade':
        if client.upgrade():
            print("Upgrade successfully, you get the write permission.")
            
    elif command=='list':
        files = client.list_files('')
        if(files==-2):
            print("Permission denied")
        elif(files==-3):
            print("The directory is locked-X, you can't read it now.")
        else:
            print("Files on the server:")
            for file in files:
                print("",file)
            
    elif command=='quit':
        break
    elif command in valid_commands:       
        file_path=[]
        file_path.append('')
        while(True):          
            print(file_path)
            files = client.list_files(file_path[-1])
            if(files==-3):
                print("The directory is locked-X, you can't read it now.")  
            else:
                print("Files on the server:", files)
                print("Is the file you want to operate in this directory or do you want to quit?(Y(y)/N(n)/Q(q))")
                ans=input()
                if (ans=='Q' or ans=='q'):
                    break
                elif(ans=='N'or ans=='n'):
                    print("Please choose a file directory to enter or do you want to go back to the last directory?")
                    folder=input()
                    if(folder=='back'):
                        file_path.pop()
                    elif file_path[-1]!='':
                        file_path.append(file_path[-1]+'\\'+folder)
                    else:
                        file_path.append(folder)           
                        
                elif(ans=='Y'or ans=='y'):  
                    
                    if command=='create_dir':
                        print("Please give the directory name.")
                        dirname=input()
                        res=client.create_dir(file_path[-1],dirname)        
                        if res==-2:
                            print("Permission denied")
                        elif(res==-3):
                            print("The directory is locked, you can't create a directory under it now.")
                        elif res==True:
                            print("The directory is sussessfully created!")
                        break
                    
                    if command=='upload':   
                        print("Please give the path you want to upload")
                        temp=input()
                        if temp=='\n':
                            temp=''
                        else:
                            temp=temp+'\\'
                        print("Please choose the file you want to upload:")
                        filename=input()
                        temp=temp+filename
                        if(file_path!=''):
                            filename=file_path[-1]+'\\'+filename
                        with open(client_root+'\\'+temp,'rb')as file:
                            res=client.write_file(filename, file.read())   
                            if res==-2:
                                print("Permission denied")
                            elif(res==-3):
                                print("The directory is locked, you can't create a directory under it now.")
                            elif res==True:
                                print("The file is sussessfully uploaded!")
                        break
                    
                    if command=='read':
                        print("Please choose the file you want to read:")
                        filename=input()
                        if(file_path[-1]!=''):
                            filename=file_path[-1]+'\\'+filename
                        content = client.read_file(filename)
                        # 将二进制数据转换为图像
                        filename, file_extension = os.path.splitext(filename)
                        if content ==-1:
                            print("Sorry,no such file.")
                        elif content==-2:
                            print("Permission denied")
                        elif content==-3:
                            print("The file/directory is locked. You can't read it now.")
                        elif not bool(file_extension):
                            print(f"The inner of the directory:{content}")
                        elif(file_extension=='.png' or file_extension=='.jpg'):
                            image = Image.open(BytesIO(content.data))
                            # 显示图像
                            image.show()
                        
                        else:
                            print(f"Content of {filename}: {content.data.decode()}")
                            # 创建 Tkinter 窗口
                            window = tk.Tk()
                            window.title("Text File Viewer")

                            # 创建一个可滚动的文本框并显示文本内容
                            text_box = scrolledtext.ScrolledText(window, wrap=tk.WORD, width=80, height=20)
                            text_box.insert(tk.END, content.data)
                            text_box.pack()

                            # 运行 Tkinter 主循环
                            window.mainloop()
                        break  
                        
                    if command=='write': 
                        print("Please choose the file you want to write:")
                        filename=input()
                        if(file_path[-1]!=''):
                            filename=file_path[-1]+'\\'+filename
                        print("Please enter the content you want to write on the file")
                        content=input()             
                        ans=client.write_file(filename, content.encode())
                        #print(ans)
                        if ans==True:
                            print("writing complished")
                        elif ans==False:
                            print("fail to write")
                        elif ans==-2:
                            print("Permission denied")  
                        elif ans==-3:
                            print("The file is locked, you can't write it now.")
                        break
                    
                    if command=='download':
                        print("Please give the path you want to download in:")
                        temp=input()
                        if temp=='\n':
                            temp=''
                        else:
                            temp=temp+'\\'+''
                        print("Please choose the file you want to download:")
                        filename=input()
                        temp=temp+filename
                        if(file_path[-1]!=''):
                            filename=file_path[-1]+'\\'+filename
                    
                        content = client.read_file(filename)
                        if content==-2:
                            print("Permission denied")
                        elif content==-3:
                            print("The file/directory is locked. You can't download it now.")
                        else:
                            with open(client_root+'\\'+temp,'wb')as file:
                                file.write(content.data)
                            print("Download successfully!")
                        break
                    
                    if command=='delete':
                        print("Please choose the file you want to delete:")
                        filename=input()
                        temp=filename
                        if(file_path[-1]!=''):
                            filename=file_path[-1]+'\\'+filename
                        content = client.delete_file(filename)
                        if content==-2:
                            print("Permission denied")
                        elif content==-3:
                            print("The file is locked, you can't delete it now.")
                        elif content==True:
                            print("The file/directory has been deleted from main server.")
                        break
    else:
        print("Invalid command.")